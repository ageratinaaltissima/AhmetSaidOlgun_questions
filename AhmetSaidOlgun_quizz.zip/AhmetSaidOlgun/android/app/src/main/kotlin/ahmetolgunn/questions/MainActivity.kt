package ahmetolgunn.questions

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
