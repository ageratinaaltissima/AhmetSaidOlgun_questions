import 'package:flutter/material.dart';
import 'package:questions/Classes/ResultPage.dart';
import 'package:questions/QuizServices/Question.dart';
import 'package:questions/QuizServices/QuizManager.dart';

class QuizzPage extends StatefulWidget {
  @override
  _QuizzPageState createState() => _QuizzPageState();
}

class _QuizzPageState extends State<QuizzPage> {
  QuizManager _manager=QuizManager();
  List<Widget> getOptions(Question question){
    List<Widget> optionButtons=[];
    for (int i=0; i<question.options.length; i++) {
      optionButtons.add(
        FlatButton(
          onPressed: (){
            _manager.nextQuestion(_manager.getCurrentQuestion().options[i].score);
            if(_manager.isFinished()){
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (context) => ResultPage(score: _manager.getTotalScore(),) )
              );
            }
            setState(() {

            });
          },
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.all(15),
            decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(10)
            ),
            child: Text("${_manager.getCurrentQuestion().options[i].text}",
              style: TextStyle(
                fontSize: 25,
              ),
            ),
          ),
        ),
      );
    }
    return optionButtons;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(""
              "Question ${_manager.getCurrentIt()}/${_manager.totalQuestion()}",
          ),
        ),
        body: Container(
          padding: EdgeInsets.all(10),
          child: Column(
            children: [
              Expanded(
                flex: 3,
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: 30),
                  child: Text(
                    "${_manager.getCurrentQuestion().text}",
                    style: TextStyle(
                      fontSize: 20,

                    ),
                  ),
                ),
              ),
              Expanded(
                flex: 7,
                child: Container(
                padding: EdgeInsets.symmetric(horizontal: 1),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: getOptions(_manager.getCurrentQuestion(),),
                ),
              ),
              ),
                      
            ],
          ),
        )
    );
  }
}
