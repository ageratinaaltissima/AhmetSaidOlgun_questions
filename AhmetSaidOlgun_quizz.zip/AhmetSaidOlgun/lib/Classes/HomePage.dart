import 'package:flutter/material.dart';
import 'package:questions/Classes/QuizzPage.dart';
import 'package:questions/Classes/ResultPage.dart';
import 'file:///D:/cet%20301/questions/lib/Classes/SehirPage.dart';

void gotoQuizzPage(BuildContext context){
  Navigator.of(context).pushReplacement(MaterialPageRoute(
  builder: (context) =>QuizzPage()),
  );
}
void gotoSehirPage(BuildContext context){
  Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (context) => SehirPage()),
  );
}
class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Quizz'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Center(
              child: Text("Merhaba sınava hos geldiniz.",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
              ),
            ),
          ),
          SizedBox(height: 40,),
          Container(
            child: Column(
              children: [

                RaisedButton(onPressed:(){gotoQuizzPage(context);},
            textColor: Colors.white,
            padding: const EdgeInsets.all(0.0),

                  child: Container(
                    width: 150,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: <Color>[
                    Color(0xFF0D47A1),
                    Color(0xFF1976D2),
                    Color(0xFF42A5F5),
                  ],
                ),
              ),
              padding: const EdgeInsets.all(10.0),
              child:
                    const Text('Tarih Sınavı' ) ,
                ),
                ),
              ],
            ),
          ),
          RaisedButton(onPressed:(){gotoSehirPage(context);},
            textColor: Colors.white,
            padding: const EdgeInsets.all(0.0),

            child: Container(
              width: 150,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: <Color>[
                    Color(0xFF0D47A1),
                    Color(0xFF1976D2),
                    Color(0xFF42A5F5),
                  ],
                ),
              ),
              padding: const EdgeInsets.all(10.0),


            child: Text('Cografya Sınavı'),
          ),
          )
        ],
      ),
    );
  }
}
