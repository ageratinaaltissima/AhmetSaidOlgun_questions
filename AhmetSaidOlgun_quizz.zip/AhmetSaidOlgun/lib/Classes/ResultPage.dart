import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
class ResultPage extends StatefulWidget {
  int score;
  ResultPage({Key key, this.score}) : super(key: key);
  @override
  _ResultPageState createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(" Sonuç "),
          ],
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Container(

              child: CircleAvatar(radius: 70,
                backgroundImage: AssetImage("assets/tebrikler.jpg"),
              )
            ),
          ),
          Text("Tebrikler Puanınız:", style:TextStyle(
            fontSize: 40,
          ),),
          Text("${widget.score}", style: TextStyle(
            fontSize: 50,
          ),),
        ],
      ),
    );
  }
}
