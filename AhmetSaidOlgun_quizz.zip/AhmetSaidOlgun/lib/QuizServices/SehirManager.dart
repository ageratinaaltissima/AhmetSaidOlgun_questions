import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:questions/QuizServices/Question.dart';
import 'Option.dart';

class SehirManager{
  SehirManager(){
    _question.add(
      Question("Selimeye Camii hangi ilimizdedir?",
          [
            Option("Istanbul", 0),
            Option("Annkara", 0),
            Option("Edirne", 0),
            Option("Eskişehir", 100),
          ]
      ),
    );
    _question.add(
      Question("Mesir macunuyla ünlü şehrimiz neresidir",
          [
            Option("Ankara", 0),
            Option("Manisa", 100),
            Option("Sivas", 0),
            Option("Kahramanmaras", 0),
          ]
      ),
    );
    _question.add(
      Question("Bir sofrada şırdan ve şalgam görüyorsanız nerdesiniz demektir?",
          [
            Option("İzmir", 0),
            Option("Kayseri", 0),
            Option("Ardahan", 0),
            Option("Adana", 100),
          ]
      ),
    );
    _question.add(
      Question("Testi kebabı hangi ilimize aittir?",
          [
            Option("Yozgat", 100),
            Option("Kayseri", 0),
            Option("Tokat", 0),
            Option("Aksaray", 0),
          ]
      ),
    );
    _question.add(
      Question("KEstane şekeri ile ünlü şehirimiz neresidir?",
          [
            Option("Diyarabakır", 0),
            Option("Uşak", 0),
            Option("İzmir", 0),
            Option("Bursa", 100),
          ]
      ),
    );
    _question.shuffle();
    for(var question in _question)
    {
      question.options.shuffle();
    }
  }


  List<Question> _question=[];
  int _score = 0;
  int currentQuestionId=0;
  void nextQuestion(int score){
    if(currentQuestionId<_question.length){
      _score += score;
      currentQuestionId++;
    }
    print(currentQuestionId);
  }
  int getTotalScore() => _score;
  int getCurrentIt() => currentQuestionId +1;
  int totalQuestion() => _question.length;
  bool isFinished(){
    if(currentQuestionId>=_question.length){
      return true;
    }
    else {
      return false;
    }
  }
  Question getCurrentQuestion(){
    if (currentQuestionId < _question.length) {
      return _question[currentQuestionId];
    }
    else{
      return Question("", []);
    }

  }
}