import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:questions/QuizServices/Question.dart';
import 'Option.dart';

class QuizManager{
  QuizManager(){
    _question.add(
      Question("Osmanlının kurucusu kimdir?",
          [
        Option("Osman Gazi", 10),
        Option("Atatürk", -5),
        Option("Fatih Sultan Mehmet", 0),
        Option("Evliya Çelebi", -5),
      ]
      ),
    );
    _question.add(
      Question("Sümer devleti nerde kurulmuştur?",
          [
            Option("Mazopotamya",10),
            Option("Orta Asya", 0),
            Option("Anadolu", 0),
          ]
      ),
    );
    _question.add(
      Question("Kosova savaşında hangi Türk Devleti savaşmıştır?",
          [
            Option("Asya Hun", 0),
            Option("Selçuklular", 0),
            Option("KArahanlılar", 0),
            Option("Osmanlı", 10),
          ]
      ),
    );
    _question.add(
    Question("Malazgirt meydan savaşı hangi tarihte yapılmıştır?",
        [
          Option("1071", 10),
          Option("1072", 0),
          Option("1073", 0),
          Option("1070", 0),
        ]
    ),
    );
  _question.shuffle();
  for(var question in _question)
    {
      question.options.shuffle();
    }
  }


  List<Question> _question=[];
  int _score = 0;
  int currentQuestionId=0;
  void nextQuestion(int score){
      if(currentQuestionId<_question.length){
        _score += score;
        currentQuestionId++;
    }
      print(currentQuestionId);
  }
  int getTotalScore() => _score;
  int getCurrentIt() => currentQuestionId +1;
  int totalQuestion() => _question.length;
  bool isFinished(){
    if(currentQuestionId>=_question.length){
      return true;
    }
    else {
      return false;
  }
  }
  Question getCurrentQuestion(){
    if (currentQuestionId < _question.length) {
      return _question[currentQuestionId];
    }
    else{
      return Question("", []);
    }

  }
}