import 'Option.dart';
class Question{
  String text;
  List<Option> options;
  Question(this.text, this.options);
}