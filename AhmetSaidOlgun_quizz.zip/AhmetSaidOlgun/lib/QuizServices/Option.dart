class Option{
  String text;
  int score;
  Option(this.text, this.score);
}